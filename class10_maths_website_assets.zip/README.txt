CLASS 10 NCERT MATHS WEBSITE ASSETS

Files:
fonts.css - Inter and Nunito font setup
favicon.svg - browser tab icon
icons/ - original SVG icons

Recommended project:
index.html
style.css
script.js
assets/
  fonts.css
  favicon.svg
  icons/

Add inside <head>:
<link rel="stylesheet" href="assets/fonts.css">
<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">

Example icon:
<img src="assets/icons/book.svg" alt="Book icon">
